# NullRAT Dependencies Installer
This is a fancy and beautiful dependencies installer worked on jointly by @usrDottik and NullCode (me)

![image](https://user-images.githubusercontent.com/70959549/148890522-fa2ee964-5a23-4e3f-ad52-e5197d1231ce.png)

## Credits
<h3>@usrDottik</h3>

- Like fr I gave him my broken C# code and he spat out a fully working, improved one
- Please go support my guy and his projects

<h3>@NullCode1337</h3>

- What else did you expect lmfao. I designed the whole thing, dot did the backend
